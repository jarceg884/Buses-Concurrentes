package Periferica_L1;
import static Periferica_L1.Bus1.busesSalidos;
import java.io.DataOutputStream;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

public class Bus9 extends Thread {
   
   //Creamos las variables
    boolean activo = true;
    public Class_Periferica periferica;
    private JLabel etiquetabus;
    String name = "";
    int tiempo = 0;
    static int i = 0;
    int c = 0;

    //Constructor
    public Bus9(Class_Periferica periferica, JLabel etiquetabus, String name, String host) {
        this.periferica = periferica;
        this.etiquetabus = etiquetabus;
        this.name = name;
        this.HOST = host;
    }
    
     public void send(int x){//Envia el mensaje servidor
         
         try {
         Socket sc = new Socket(HOST, PUERTO);
                    
        out = new DataOutputStream(sc.getOutputStream());

        out.writeUTF(name+" | Parada "+x);
        sc.close();
        } catch (IOException ex) {
             Logger.getLogger(Bus2.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
     
     public void sendC(){//Envia el mensaje servidor
         
         try {
         Socket sc = new Socket(HOST, PUERTO);
                    
        out = new DataOutputStream(sc.getOutputStream());

        out.writeUTF(name+" | Concure con Bus 8");
        sc.close(); 
        } catch (IOException ex) {
             Logger.getLogger(Bus2.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
     
      //**TCP CONFIG
    String HOST = "127.0.0.9";    
    final int PUERTO = 5000;
    DataOutputStream out;
    String text[] = new String[2];    

    @Override
    public void run(){
        i = 1;
       int x;
       int y;

       while (activo == true){
           while (busesSalidos < 8) {
        try {
            //esperar a que los buses anteriores hayan salido
            sleep(1500); // espera 100 milisegundos antes de verificar de nuevo
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
           
           tiempo= 750;
           
           if (i == 1) {
               
               x = periferica.getParada1().getX();
               y = periferica.getParada1().getY();
               etiquetabus.setLocation(x,y); 
               send(1);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
           busesSalidos++;
            }
           
             if (i == 2) {
               
               x = periferica.getParada_I1().getX();
               y = periferica.getParada_I1().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 3) {
               
               x = periferica.getParada2().getX();
               y = periferica.getParada2().getY();
               etiquetabus.setLocation(x,y);
               send(2);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            }
             if (i == 4) {
               
               x = periferica.getParada_I2().getX();
               y = periferica.getParada_I2().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 5) {
               
               x = periferica.getParada3().getX();
               y = periferica.getParada3().getY();
               etiquetabus.setLocation(x,y); 
               send(3);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 6) {
               
               x = periferica.getParada_I3().getX();
               y = periferica.getParada_I3().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 7) {
               
               x = periferica.getParada4().getX();
               y = periferica.getParada4().getY();
               etiquetabus.setLocation(x,y);  
               send(4);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 8) {
               
               x = periferica.getParada_I4().getX();
               y = periferica.getParada_I4().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 9) {
               
               x = periferica.getParada5().getX();
               y = periferica.getParada5().getY();
               etiquetabus.setLocation(x,y); 
               send(5);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 10) {
               
               x = periferica.getParada_I5().getX();
               y = periferica.getParada_I5().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 11) {
               
               x = periferica.getParada_I6().getX();
               y = periferica.getParada_I6().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 12) {
               
               x = periferica.getParada6().getX();
               y = periferica.getParada6().getY();
               etiquetabus.setLocation(x,y); 
               send(6);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 13) {
               
               x = periferica.getParada_I7().getX();
               y = periferica.getParada_I7().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 14) {
               
               x = periferica.getParada7().getX();
               y = periferica.getParada7().getY();
               etiquetabus.setLocation(x,y); 
               send(7);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 15) {
               
               x = periferica.getParada_I8().getX();
               y = periferica.getParada_I8().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 16) {
               
               x = periferica.getParada8().getX();
               y = periferica.getParada8().getY();
               etiquetabus.setLocation(x,y); 
               send(8);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 17) {
               
               x = periferica.getParada_I9().getX();
               y = periferica.getParada_I9().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 18) {
               
               x = periferica.getParada_I10().getX();
               y = periferica.getParada_I10().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 19) {
               
               x = periferica.getParada9().getX();
               y = periferica.getParada9().getY();
               etiquetabus.setLocation(x,y);  
               send(9);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 20) {
               
               x = periferica.getParada_I11().getX();
               y = periferica.getParada_I11().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 21) {
               
               x = periferica.getParada10().getX();
               y = periferica.getParada10().getY();
               etiquetabus.setLocation(x,y); 
               send(10);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 22) {
               
               x = periferica.getParada_I12().getX();
               y = periferica.getParada_I12().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 23) {
               
               x = periferica.getParada11().getX();
               y = periferica.getParada11().getY();
               etiquetabus.setLocation(x,y); 
               send(11);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 24) {
               
               x = periferica.getParada_I13().getX();
               y = periferica.getParada_I13().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 25) {
               
               x = periferica.getParada12().getX();
               y = periferica.getParada12().getY();
               etiquetabus.setLocation(x,y);   
               send(12);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 26) {
               
               x = periferica.getParada_I14().getX();
               y = periferica.getParada_I14().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 27) {
               
               x = periferica.getParada13().getX();
               y = periferica.getParada13().getY();
               etiquetabus.setLocation(x,y); 
               send(13);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 28) {
               
               x = periferica.getParada_I15().getX();
               y = periferica.getParada_I15().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 29) {
               
               x = periferica.getParada14().getX();
               y = periferica.getParada14().getY();
               etiquetabus.setLocation(x,y);
               send(14);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 30) {
               
               x = periferica.getParada_I16().getX();
               y = periferica.getParada_I16().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 31) {
               
               x = periferica.getParada15().getX();
               y = periferica.getParada15().getY();
               etiquetabus.setLocation(x,y);
               send(15);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 32) {
               
               x = periferica.getParada_I17().getX();
               y = periferica.getParada_I17().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 33) {
               
               x = periferica.getParada16().getX();
               y = periferica.getParada16().getY();
               etiquetabus.setLocation(x,y); 
               send(16);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 34) {
               
               x = periferica.getParada_I18().getX();
               y = periferica.getParada_I18().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 35) {
               
               x = periferica.getParada17().getX();
               y = periferica.getParada17().getY();
               etiquetabus.setLocation(x,y); 
               send(17);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 36) {
               
               x = periferica.getParada_I19().getX();
               y = periferica.getParada_I19().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 37) {
               
               x = periferica.getParada18().getX();
               y = periferica.getParada18().getY();
               etiquetabus.setLocation(x,y); 
               send(18);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 38) {
               
               x = periferica.getParada_I20().getX();
               y = periferica.getParada_I20().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 39) {
               
               x = periferica.getParada19().getX();
               y = periferica.getParada19().getY();
               etiquetabus.setLocation(x,y);
               send(19);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 40) {
               
               x = periferica.getParada_I21().getX();
               y = periferica.getParada_I21().getY();
               etiquetabus.setLocation(x,y);   
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 41) {
               
               x = periferica.getParada20().getX();
               y = periferica.getParada20().getY();
               etiquetabus.setLocation(x,y);  
               send(20);
               
               i++;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
            } 
             if (i == 42) {
               
               x = periferica.getParada_I22().getX();
               y = periferica.getParada_I22().getY();
               etiquetabus.setLocation(x,y);  
               
               
               i=1;
               periferica.repaint();
           try{
               sleep(tiempo);
               }catch(InterruptedException e){
               System.out.println(e);
                }
           c++;
           
           if(c>60){
               this.activo = false;
           }
           
           try{
               sleep(tiempo);
           }catch (InterruptedException e){
               
           }
            } 
             
       }
    }
}
