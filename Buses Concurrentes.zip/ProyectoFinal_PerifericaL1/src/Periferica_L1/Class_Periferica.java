package Periferica_L1;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import javax.swing.JDialog;
import javax.swing.JLabel;


public class Class_Periferica extends javax.swing.JFrame {

    public Class_Periferica () {
        // Inicializamos los componentes de la interfaz gráfica.
        initComponents();
        // Establecemos la ubicación relativa de la ventana a null para que se centre en la pantalla.
        this.setLocationRelativeTo(null);
        // Establecemos el título de la ventana.
        this.setTitle("Periferica_L1");
        reloj.setVisible(true);
    }
    // Declaramos las variables estáticas para cada autobús en el programa.
    // Cada variable corresponde a una instancia de una clase de autobús específica, que se utiliza para rastrear
    // el estado y la ubicación de ese autobús en particular en el programa.
    public static Bus1 b1;
    public static Bus2 b2;
    public static Bus3 b3;
    public static Bus4 b4;
    public static Bus5 b5;
    public static Bus6 b6;
    public static Bus7 b7;
    public static Bus8 b8;
    public static Bus9 b9;
    public static Bus10 b10;
    boolean inicioPresionado = false; // Declaración de la variable booleana
    Reloj reloj = new Reloj();

    
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //Obtencion de los autobuses y las paradas
    //Buses 1-20 
    
    public JLabel getPrimerBus(){
        return Label_Bus1;
    }
        public JLabel getSegundoBus(){
        return Label_Bus2;
    }    
    public JLabel getTercerBus(){
        return Label_Bus3;
    }
    public JLabel getCuartoBus(){
        return Label_Bus4;
    }
    
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //Paradas
    
    public JLabel getParada1(){
        return Parada1;
    }
    public JLabel getParada2(){
        return Parada2;
    }
    public JLabel getParada3(){
        return Parada3;
    }
    public JLabel getParada4(){
        return Parada4;
    }
    public JLabel getParada5(){
        return Parada5;
    }
    public JLabel getParada6(){
        return Parada6;
    }
    public JLabel getParada7(){
        return Parada7;
    }
    public JLabel getParada8(){
        return Parada8;
    }
    public JLabel getParada9(){
        return Parada9;
    }
    public JLabel getParada10(){
        return Parada10;
    }
    public JLabel getParada11(){
        return Parada11;
    }
    public JLabel getParada12(){
        return Parada12;
    }
    public JLabel getParada13(){
        return Parada13;
    }
    public JLabel getParada14(){
        return Parada14;
    }
    public JLabel getParada15(){
        return Parada15;
    }
    public JLabel getParada16(){
        return Parada16;
    }
    public JLabel getParada17(){
        return Parada17;
    }
    public JLabel getParada18(){
        return Parada18;
    }
    public JLabel getParada19(){
        return Parada19;
    }
    public JLabel getParada20(){
        return Parada20;
    }
    
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //Paradas invisibles 
    
    public JLabel getParada_I1(){
        return Parada_invisible1;
    }
    public JLabel getParada_I2(){
        return Parada_invisible2;
    }
    public JLabel getParada_I3(){
        return Parada_invisible3;
    }
    public JLabel getParada_I4(){
        return Parada_invisible4;
    }
    public JLabel getParada_I5(){
        return Parada_invisible5;
    }
    public JLabel getParada_I6(){
        return Parada_invisible6;
    }
    public JLabel getParada_I7(){
        return Parada_invisible7;
    }
    public JLabel getParada_I8(){
        return Parada_invisible8;
    }
    public JLabel getParada_I9(){
        return Parada_invisible9;
    }
    public JLabel getParada_I10(){
        return Parada_invisible10;
    }
    public JLabel getParada_I11(){
        return Parada_invisible11;
    }
    public JLabel getParada_I12(){
        return Parada_invisible12;
    }
    public JLabel getParada_I13(){
        return Parada_invisible13;
    }
    public JLabel getParada_I14(){
        return Parada_invisible14;
    }
    public JLabel getParada_I15(){
        return Parada_invisible15;
    }
    public JLabel getParada_I16(){
        return Parada_invisible16;
    }
    public JLabel getParada_I17(){
        return Parada_invisible17;
    }
    public JLabel getParada_I18(){
        return Parada_invisible18;
    }
    public JLabel getParada_I19(){
        return Parada_invisible19;
    }
    public JLabel getParada_I20(){
        return Parada_invisible20;
    }
    public JLabel getParada_I21(){
        return Parada_invisible21;
    }
    public JLabel getParada_I22(){
        return Parada_invisible22;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Icon_audio = new javax.swing.JLabel();
        Icon_audio0 = new javax.swing.JLabel();
        Icon_titulo = new javax.swing.JLabel();
        Boton_inicio = new javax.swing.JButton();
        Boton_detener = new javax.swing.JButton();
        Panel_pantalla = new javax.swing.JPanel();
        Label_Bus1 = new javax.swing.JLabel();
        Label_Bus2 = new javax.swing.JLabel();
        Label_Bus3 = new javax.swing.JLabel();
        Label_Bus4 = new javax.swing.JLabel();
        Label_Bus5 = new javax.swing.JLabel();
        Label_Bus6 = new javax.swing.JLabel();
        Label_Bus7 = new javax.swing.JLabel();
        Label_Bus8 = new javax.swing.JLabel();
        Label_Bus9 = new javax.swing.JLabel();
        Label_Bus10 = new javax.swing.JLabel();
        Parada1 = new javax.swing.JLabel();
        Parada2 = new javax.swing.JLabel();
        Parada3 = new javax.swing.JLabel();
        Parada4 = new javax.swing.JLabel();
        Parada5 = new javax.swing.JLabel();
        Parada6 = new javax.swing.JLabel();
        Parada7 = new javax.swing.JLabel();
        Parada8 = new javax.swing.JLabel();
        Parada9 = new javax.swing.JLabel();
        Parada10 = new javax.swing.JLabel();
        Parada11 = new javax.swing.JLabel();
        Parada12 = new javax.swing.JLabel();
        Parada13 = new javax.swing.JLabel();
        Parada14 = new javax.swing.JLabel();
        Parada15 = new javax.swing.JLabel();
        Parada16 = new javax.swing.JLabel();
        Parada17 = new javax.swing.JLabel();
        Parada18 = new javax.swing.JLabel();
        Parada19 = new javax.swing.JLabel();
        Parada20 = new javax.swing.JLabel();
        Parada_invisible1 = new javax.swing.JLabel();
        Parada_invisible2 = new javax.swing.JLabel();
        Parada_invisible3 = new javax.swing.JLabel();
        Parada_invisible4 = new javax.swing.JLabel();
        Parada_invisible5 = new javax.swing.JLabel();
        Parada_invisible6 = new javax.swing.JLabel();
        Parada_invisible7 = new javax.swing.JLabel();
        Parada_invisible8 = new javax.swing.JLabel();
        Parada_invisible9 = new javax.swing.JLabel();
        Parada_invisible10 = new javax.swing.JLabel();
        Parada_invisible11 = new javax.swing.JLabel();
        Parada_invisible12 = new javax.swing.JLabel();
        Parada_invisible13 = new javax.swing.JLabel();
        Parada_invisible14 = new javax.swing.JLabel();
        Parada_invisible15 = new javax.swing.JLabel();
        Parada_invisible16 = new javax.swing.JLabel();
        Parada_invisible17 = new javax.swing.JLabel();
        Parada_invisible18 = new javax.swing.JLabel();
        Parada_invisible19 = new javax.swing.JLabel();
        Parada_invisible20 = new javax.swing.JLabel();
        Parada_invisible21 = new javax.swing.JLabel();
        Parada_invisible22 = new javax.swing.JLabel();
        Periferica = new javax.swing.JLabel();
        Boton_Reloj = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Icon_audio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Icon-audio.png"))); // NOI18N

        Icon_audio0.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Icon-audio.png"))); // NOI18N

        Icon_titulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Icon-Periferica.png"))); // NOI18N

        Boton_inicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Icon-start.png"))); // NOI18N
        Boton_inicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Boton_inicioActionPerformed(evt);
            }
        });

        Boton_detener.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Icon-stop.png"))); // NOI18N
        Boton_detener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Boton_detenerActionPerformed(evt);
            }
        });

        Panel_pantalla.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Panel_pantalla.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Label_Bus1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus1.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        Label_Bus2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus2.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, -1, -1));

        Label_Bus3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus3.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, -1, -1));

        Label_Bus4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus4.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, -1));

        Label_Bus5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus5.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        Label_Bus6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus6.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, -1, -1));

        Label_Bus7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus7.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 20, -1, -1));

        Label_Bus8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus8.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus8, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, -1, -1));

        Label_Bus9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus9.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus9, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, -1));

        Label_Bus10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Label_Bus10.png"))); // NOI18N
        Panel_pantalla.add(Label_Bus10, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, -1, -1));

        Parada1.setBackground(new java.awt.Color(255, 0, 0));
        Parada1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 120, -1, 40));

        Parada2.setBackground(new java.awt.Color(255, 0, 0));
        Parada2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 110, -1, 40));

        Parada3.setBackground(new java.awt.Color(255, 0, 0));
        Parada3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada3, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, -1, 40));

        Parada4.setBackground(new java.awt.Color(255, 0, 0));
        Parada4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, -1, 40));

        Parada5.setBackground(new java.awt.Color(255, 0, 0));
        Parada5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada5, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 200, -1, 40));

        Parada6.setBackground(new java.awt.Color(255, 0, 0));
        Parada6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 270, -1, 40));

        Parada7.setBackground(new java.awt.Color(255, 0, 0));
        Parada7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada7, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 340, -1, 40));

        Parada8.setBackground(new java.awt.Color(255, 0, 0));
        Parada8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada8, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 390, -1, 40));

        Parada9.setBackground(new java.awt.Color(255, 0, 0));
        Parada9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada9, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 400, -1, 40));

        Parada10.setBackground(new java.awt.Color(255, 0, 0));
        Parada10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada10, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 390, -1, 40));

        Parada11.setBackground(new java.awt.Color(255, 0, 0));
        Parada11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada11, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, -1, 40));

        Parada12.setBackground(new java.awt.Color(255, 0, 0));
        Parada12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada12, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 390, -1, 40));

        Parada13.setBackground(new java.awt.Color(255, 0, 0));
        Parada13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada13, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 340, -1, 40));

        Parada14.setBackground(new java.awt.Color(255, 0, 0));
        Parada14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada14, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, -1, 40));

        Parada15.setBackground(new java.awt.Color(255, 0, 0));
        Parada15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada15, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, -1, 40));

        Parada16.setBackground(new java.awt.Color(255, 0, 0));
        Parada16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada16, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, -1, 40));

        Parada17.setBackground(new java.awt.Color(255, 0, 0));
        Parada17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada17, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, -1, 40));

        Parada18.setBackground(new java.awt.Color(255, 0, 0));
        Parada18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada18, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 160, -1, 40));

        Parada19.setBackground(new java.awt.Color(255, 0, 0));
        Parada19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada19, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 120, -1, 40));

        Parada20.setBackground(new java.awt.Color(255, 0, 0));
        Parada20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada.png"))); // NOI18N
        Panel_pantalla.add(Parada20, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, -1, 40));

        Parada_invisible1.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, -1, 40));

        Parada_invisible2.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 90, -1, 40));

        Parada_invisible3.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 110, -1, 40));

        Parada_invisible4.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 160, -1, 40));

        Parada_invisible5.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible5, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 200, -1, 40));

        Parada_invisible6.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 240, -1, 40));

        Parada_invisible7.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible7, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 310, -1, 40));

        Parada_invisible8.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible8, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 370, -1, 40));

        Parada_invisible9.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible9, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 380, -1, 40));

        Parada_invisible10.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible10, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 410, -1, 40));

        Parada_invisible11.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible11, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 390, -1, 40));

        Parada_invisible12.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible12, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 390, -1, 40));

        Parada_invisible13.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible13, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, -1, 40));

        Parada_invisible14.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible14, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, -1, 40));

        Parada_invisible15.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible15, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, -1, 40));

        Parada_invisible16.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible16, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 300, -1, 40));

        Parada_invisible17.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 300, -1, 40));

        Parada_invisible18.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible18, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, -1, 40));

        Parada_invisible19.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible19, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, -1, 40));

        Parada_invisible20.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible20, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, -1, 40));

        Parada_invisible21.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible21, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, -1, 40));

        Parada_invisible22.setBackground(new java.awt.Color(255, 0, 0));
        Parada_invisible22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/parada_invisible.png"))); // NOI18N
        Panel_pantalla.add(Parada_invisible22, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, -1, 40));

        Periferica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Pista.png"))); // NOI18N
        Periferica.setAutoscrolls(true);
        Panel_pantalla.add(Periferica, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 500));

        Boton_Reloj.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pistacarros/imagenes/Icon_Clock.png"))); // NOI18N
        Boton_Reloj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Boton_RelojActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Icon_audio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Icon_titulo)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Panel_pantalla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Boton_inicio)
                                .addGap(16, 16, 16)
                                .addComponent(Boton_detener)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Boton_Reloj)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Icon_audio0)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(Icon_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Panel_pantalla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(Icon_audio)
                                .addGap(203, 203, 203))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(311, 311, 311)
                        .addComponent(Icon_audio0)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Boton_inicio, javax.swing.GroupLayout.PREFERRED_SIZE, 53, Short.MAX_VALUE)
                    .addComponent(Boton_detener, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(Boton_Reloj, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Boton_inicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Boton_inicioActionPerformed
        // TODO add your handling code here:
        
    if(!inicioPresionado){    
    
    // Establecemos la ubicación de cada etiqueta de autobús en la ubicación de la Parada1 en la interfaz gráfica.
    // Cada etiqueta corresponde a un autobús específico, y se utiliza para mostrar información sobre el estado
    // del autobús en cuestión.
    Label_Bus1.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus2.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus3.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus4.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus5.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus6.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus7.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus8.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus9.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    Label_Bus10.setLocation(Parada1.getLocation().x,Parada1.getLocation().y);
    
    // Creamos 10 objetos de la clase BusX, cada uno correspondiente a un bus en la interfaz gráfica.
    // Pasamos la ventana principal como primer argumento, y la etiqueta correspondiente al bus en cuestión
    // como segundo argumento. El tercer argumento es simplemente una cadena con el nombre del bus para
    // fines de registro y seguimiento.
    b1 = new Bus1(this,Label_Bus1,"Bus1", "127.0.0.1");  
    b2 = new Bus2(this,Label_Bus2,"Bus2", "127.0.0.2");
    b3 = new Bus3(this,Label_Bus3,"Bus3", "127.0.0.3");
    b4 = new Bus4(this,Label_Bus4,"Bus4", "127.0.0.4");
    b5 = new Bus5(this,Label_Bus5,"Bus5", "127.0.0.5");
    b6 = new Bus6(this,Label_Bus6,"Bus6", "127.0.0.6");
    b7 = new Bus7(this,Label_Bus7,"Bus7", "127.0.0.7");
    b8 = new Bus8(this,Label_Bus8,"Bus8", "127.0.0.8");
    b9 = new Bus9(this,Label_Bus9,"Bus9", "127.0.0.9");
    b10 = new Bus10(this,Label_Bus10,"Bus10", "127.0.0.10"); 

    // Llamar al método start() para iniciar la ejecución de la clase Bus1
    b1.start();
    b2.start();
    b3.start();
    b4.start();
    b5.start();
    b6.start();
    b7.start();
    b8.start();
    b9.start();
    b10.start();
    
    // Cambio de estado de los botones
    inicioPresionado = true;
    Boton_inicio.setEnabled(false);
    Boton_detener.setEnabled(true);
    }
    }//GEN-LAST:event_Boton_inicioActionPerformed

    private void Boton_detenerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Boton_detenerActionPerformed
        // TODO add your handling code here:  
    //Detenemos el programa    
     b1.stop();
     b2.stop();
     b3.stop();
     b4.stop();
     b5.stop();
     b6.stop();
     b7.stop();
     b8.stop();
     b9.stop();
     b10.stop();
    
     // Llama al método setBusesSalidos de la instancia de Bus1 creada en la clase Class_Periferica
     b1.setBusesSalidos(0);
    // Cambio de estado de los botones 
    inicioPresionado = false;
    Boton_inicio.setEnabled(true);
    Boton_detener.setEnabled(false);
    
        
        
    }//GEN-LAST:event_Boton_detenerActionPerformed

    private void Boton_RelojActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Boton_RelojActionPerformed
        // TODO add your handling code here:

        if (!reloj.isShowing()){
            reloj.setVisible(true);
        }else{
            reloj.dispose();
        }
    
    }//GEN-LAST:event_Boton_RelojActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Class_Periferica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Class_Periferica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Class_Periferica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Class_Periferica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Class_Periferica().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Boton_Reloj;
    private javax.swing.JButton Boton_detener;
    private javax.swing.JButton Boton_inicio;
    private javax.swing.JLabel Icon_audio;
    private javax.swing.JLabel Icon_audio0;
    private javax.swing.JLabel Icon_titulo;
    private javax.swing.JLabel Label_Bus1;
    private javax.swing.JLabel Label_Bus10;
    private javax.swing.JLabel Label_Bus2;
    private javax.swing.JLabel Label_Bus3;
    private javax.swing.JLabel Label_Bus4;
    private javax.swing.JLabel Label_Bus5;
    private javax.swing.JLabel Label_Bus6;
    private javax.swing.JLabel Label_Bus7;
    private javax.swing.JLabel Label_Bus8;
    private javax.swing.JLabel Label_Bus9;
    private javax.swing.JPanel Panel_pantalla;
    private javax.swing.JLabel Parada1;
    private javax.swing.JLabel Parada10;
    private javax.swing.JLabel Parada11;
    private javax.swing.JLabel Parada12;
    private javax.swing.JLabel Parada13;
    private javax.swing.JLabel Parada14;
    private javax.swing.JLabel Parada15;
    private javax.swing.JLabel Parada16;
    private javax.swing.JLabel Parada17;
    private javax.swing.JLabel Parada18;
    private javax.swing.JLabel Parada19;
    private javax.swing.JLabel Parada2;
    private javax.swing.JLabel Parada20;
    private javax.swing.JLabel Parada3;
    private javax.swing.JLabel Parada4;
    private javax.swing.JLabel Parada5;
    private javax.swing.JLabel Parada6;
    private javax.swing.JLabel Parada7;
    private javax.swing.JLabel Parada8;
    private javax.swing.JLabel Parada9;
    private javax.swing.JLabel Parada_invisible1;
    private javax.swing.JLabel Parada_invisible10;
    private javax.swing.JLabel Parada_invisible11;
    private javax.swing.JLabel Parada_invisible12;
    private javax.swing.JLabel Parada_invisible13;
    private javax.swing.JLabel Parada_invisible14;
    private javax.swing.JLabel Parada_invisible15;
    private javax.swing.JLabel Parada_invisible16;
    private javax.swing.JLabel Parada_invisible17;
    private javax.swing.JLabel Parada_invisible18;
    private javax.swing.JLabel Parada_invisible19;
    private javax.swing.JLabel Parada_invisible2;
    private javax.swing.JLabel Parada_invisible20;
    private javax.swing.JLabel Parada_invisible21;
    private javax.swing.JLabel Parada_invisible22;
    private javax.swing.JLabel Parada_invisible3;
    private javax.swing.JLabel Parada_invisible4;
    private javax.swing.JLabel Parada_invisible5;
    private javax.swing.JLabel Parada_invisible6;
    private javax.swing.JLabel Parada_invisible7;
    private javax.swing.JLabel Parada_invisible8;
    private javax.swing.JLabel Parada_invisible9;
    private javax.swing.JLabel Periferica;
    // End of variables declaration//GEN-END:variables
}
