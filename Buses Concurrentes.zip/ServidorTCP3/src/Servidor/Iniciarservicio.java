package Servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

public class Iniciarservicio {
        Calendar calendar;
        static SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a");;
        JPanel timePanel;
        static String time;
    
    public static String hora(){//Para la hora
        
        time = timeFormat.format(Calendar.getInstance().getTime());
        return time;
        }
    
    public static void main(String[] args) {
        ServerSocket servidor = null;
        Socket sc = null;
        DataInputStream in;
        DataOutputStream out;
        //Los puertos 1024 al 49151
        final int PUERTO = 5000;
        
        frmAC panel = new frmAC();
        panel.setVisible(true);
  
        //Mensaje que se agrega a la tabla
        String fila[] = new String[2];
        

        
        try {
            servidor = new ServerSocket(PUERTO);
            
            System.out.println("Servidor iniciado");
            
            while(true){
                sc = servidor.accept();
                
                in = new DataInputStream(sc.getInputStream());
                out = new DataOutputStream(sc.getOutputStream());
                
                String mensaje = in.readUTF();
                
                fila[0] = mensaje;
                fila[1] = hora();
                
                
                
                if (sc.getLocalAddress().toString().equals("/127.0.0.1")){
                    panel.tabla[0].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.2")){
                    panel.tabla[1].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.3")){
                    panel.tabla[2].n.addRow(fila);
                }
                
                if (sc.getLocalAddress().toString().equals("/127.0.0.4")){
                    panel.tabla[3].n.addRow(fila);
                }
                
                if (sc.getLocalAddress().toString().equals("/127.0.0.5")){
                    panel.tabla[4].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.6")){
                    panel.tabla[5].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.7")){
                    panel.tabla[6].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.8")){
                    panel.tabla[7].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.9")){
                    panel.tabla[8].n.addRow(fila);
                }
                if (sc.getLocalAddress().toString().equals("/127.0.0.10")){
                    panel.tabla[9].n.addRow(fila);
                }
                sc.close();
            }
            
            
        } catch (IOException ex) {
            Logger.getLogger(Iniciarservicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    

}
